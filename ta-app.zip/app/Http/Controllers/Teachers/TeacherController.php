<?php

namespace App\Http\Controllers\Teachers;

use App\Http\Controllers\Controller;

class TeacherController extends Controller
{

}
