import TeacherSupport from "./TeacherSupport.js";

const teacherSupport = new TeacherSupport();

$(document).ready(function () {

});
