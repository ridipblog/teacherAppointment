import RequestSupport from "../Support/RequestSupport.js";

class TeacherSupport extends RequestSupport{
    constructor(){
        super();
    }
}

export default TeacherSupport;
